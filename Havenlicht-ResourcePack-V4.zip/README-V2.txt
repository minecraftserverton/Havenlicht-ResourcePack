HAVENLICHT HUD V2 — Minecraft Java 26.3

V2:
- compacte vanilla-afmetingen
- donker steen/metaal frame
- verweerd messing/goud
- Havenlicht-blauwe inlays
- duidelijker goud geselecteerd slot
- vernieuwde XP-balk

Upload deze ZIP als vervanging op GitHub.
Na vervanging verandert de SHA-1; gebruik de SHA-1 uit het losse tekstbestand.

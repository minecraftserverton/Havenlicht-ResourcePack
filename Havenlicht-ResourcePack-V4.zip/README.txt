HAVENLICHT RESOURCE PACK — Minecraft Java 26.3

Inhoud:
- Custom Havenlicht hotbar
- Gouden geselecteerd-slot
- Havenlicht XP-balk
- Custom armor, hunger en alle heart-statusvarianten
- Pack format 97.1 voor Minecraft Java 26.3

SERVERINSTALLATIE
1. Host Havenlicht-ResourcePack-26.3.zip op een directe HTTPS-download-URL.
2. Zet in server.properties:
   resource-pack=<DIRECTE-HTTPS-URL>
   resource-pack-sha1=<SHA1 hieronder>
   require-resource-pack=true
3. Herstart Paper.
4. Spelers krijgen het pack bij het joinen aangeboden/verplicht.

Let op: resource-pack moet een directe downloadlink zijn, niet een normale webpagina.

SHA1 van deze ZIP:
eaf5bd861c1b68f71eed7807af935acdd81ec2c3
